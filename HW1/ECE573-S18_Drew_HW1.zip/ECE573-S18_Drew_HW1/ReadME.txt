"""
Tina Drew - 035006375
ECE573 - Spring 2018
Homework 1

Please note that most of the programs in the homework test all the 
contents in the directory with a .txt extension
When the program opens a file dialog menu will pop up asking
you to select a file.  
Please select a file in directory that you want to test
If you want to test a single file, create a new folder and put that file 
in to that folder. The run the program on directory of the new folder. 
"""